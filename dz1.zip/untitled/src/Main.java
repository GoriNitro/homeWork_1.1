import java.net.SocketOptions;
public class Main {
    public static void main(String[] args) {
        String MyFavouriteFood = "";
        //п

        int Num = 12;
        //в

        final String word = "nebula";
        //т

        MyFavouriteFood = (word + Num);
        //ч

        System.out.println(MyFavouriteFood + word + Num);
        //п

        if (Num>=1) {
            System.out.println("Вы сохранили положительное число");}
        else if (Num==0) {
            System.out.println("Вы сохранили ноль");}
        else {
            System.out.println("Вы сохранили отрицательное0 число");}
        //ш
        }
    }
